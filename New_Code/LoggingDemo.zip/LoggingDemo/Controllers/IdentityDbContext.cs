﻿namespace UserAuthentication.Data
{
    public class IdentityDbContext
    {
    }
}